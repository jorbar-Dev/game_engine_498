SpriteController = {

	OnStart = function(self)
		self.pos = Vector2(0, 0)
		self.rot_degrees = 0
	end,

	OnUpdate = function(self)
		self.rb = self.actor:GetComponent("Rigidbody")

		if self.rb ~= nil then
			self.pos = self.rb:GetPosition()
			self.rot_degrees = self.rb:GetRotation()
		end

		self.SPC = self.actor:GetComponent("SpriteRenderer_C")

		if self.SPC ~= nil then
			self.SPC:SetPosition(self.pos)
			self.SPC:SetRotation(self.rot_degrees)
			--print("Updating sprite position")
		end
	end
}


#pragma once
#include <string>
#include <filesystem>
#include "gameEngineUtils.h"
#include <vector>
#include "MapHelper.h"
#include "Actor_C.h"
#include <unordered_map>
#include "TemplateDB.h"
#include "ImageDB.h"
#include <optional>
#include "LuaHandler.h"

static class StaticFindOperations
{
public:


};

